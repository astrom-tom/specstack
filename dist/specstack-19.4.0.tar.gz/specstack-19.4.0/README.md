# specstack

specstack is a very simple open source tool (GNU3.0) able to stack spectra of galaxies together


