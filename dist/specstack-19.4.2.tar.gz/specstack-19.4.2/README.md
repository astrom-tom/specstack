# specstack

The full documentation can be found [here](https://astrom-tom.github.io/specstack/)

